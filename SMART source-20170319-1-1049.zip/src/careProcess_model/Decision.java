/**
 */
package careProcess_model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see careProcess_model.CareProcess_modelPackage#getDecision()
 * @model
 * @generated
 */
public interface Decision extends Step {
} // Decision
