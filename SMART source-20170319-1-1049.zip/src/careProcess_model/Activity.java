/**
 */
package careProcess_model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see careProcess_model.CareProcess_modelPackage#getActivity()
 * @model
 * @generated
 */
public interface Activity extends Step {
} // Activity
