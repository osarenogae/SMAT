/**
 */
package careProcess_model;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hazard Factor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see careProcess_model.CareProcess_modelPackage#getHazardFactor()
 * @model abstract="true"
 * @generated
 */
public interface HazardFactor extends EObject {
} // HazardFactor
