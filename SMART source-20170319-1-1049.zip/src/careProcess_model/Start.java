/**
 */
package careProcess_model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Start</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see careProcess_model.CareProcess_modelPackage#getStart()
 * @model
 * @generated
 */
public interface Start extends Step {
} // Start
