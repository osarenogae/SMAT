/**
 */
package careProcess_model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see careProcess_model.CareProcess_modelPackage#getStop()
 * @model
 * @generated
 */
public interface Stop extends Step {
} // Stop
